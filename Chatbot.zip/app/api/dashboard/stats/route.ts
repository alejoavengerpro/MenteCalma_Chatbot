import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = await createClient()
    
    // Get user session
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }
    
    // Check if user is staff
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single()
    
    if (!profile || !["psychologist", "tutor", "coordinator", "admin"].includes(profile.role)) {
      return NextResponse.json({ error: "Acceso denegado" }, { status: 403 })
    }
    
    // Get dashboard statistics
    const now = new Date()
    const startOfWeek = new Date(now)
    startOfWeek.setDate(now.getDate() - 7)
    
    // Total students
    const { count: totalStudents } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("role", "student")
    
    // Active sessions this week
    const { count: activeSessions } = await supabase
      .from("chat_sessions")
      .select("*", { count: "exact", head: true })
      .gte("created_at", startOfWeek.toISOString())
    
    // Pending alerts
    const { count: pendingAlerts } = await supabase
      .from("crisis_alerts")
      .select("*", { count: "exact", head: true })
      .eq("status", "pending")
    
    // Risk distribution
    const { data: riskData } = await supabase
      .from("chat_sessions")
      .select("risk_level")
      .gte("created_at", startOfWeek.toISOString())
    
    const riskDistribution = {
      low: 0,
      moderate: 0,
      high: 0
    }
    
    riskData?.forEach(session => {
      if (session.risk_level && riskDistribution.hasOwnProperty(session.risk_level)) {
        riskDistribution[session.risk_level as keyof typeof riskDistribution]++
      }
    })
    
    // Weekly trend
    const { data: weeklyData } = await supabase
      .from("chat_sessions")
      .select("created_at, risk_level")
      .gte("created_at", startOfWeek.toISOString())
      .order("created_at", { ascending: true })
    
    // Group by day
    const dailyStats: Record<string, { total: number; high: number; moderate: number; low: number }> = {}
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(now)
      date.setDate(now.getDate() - (6 - i))
      const dateKey = date.toISOString().split("T")[0]
      dailyStats[dateKey] = { total: 0, high: 0, moderate: 0, low: 0 }
    }
    
    weeklyData?.forEach(session => {
      const dateKey = session.created_at.split("T")[0]
      if (dailyStats[dateKey]) {
        dailyStats[dateKey].total++
        if (session.risk_level) {
          dailyStats[dateKey][session.risk_level as "high" | "moderate" | "low"]++
        }
      }
    })
    
    const weeklyTrend = Object.entries(dailyStats).map(([date, stats]) => ({
      date,
      day: new Date(date).toLocaleDateString("es-PE", { weekday: "short" }),
      ...stats
    }))
    
    return NextResponse.json({
      totalStudents: totalStudents || 0,
      activeSessions: activeSessions || 0,
      pendingAlerts: pendingAlerts || 0,
      riskDistribution,
      weeklyTrend
    })
    
  } catch (error) {
    console.error("Dashboard stats error:", error)
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    )
  }
}
