import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { analyzeRisk } from '@/lib/risk-analyzer'
import type { CulturalDictionary, Intervention } from '@/lib/types'

export async function POST(req: Request) {
  try {
    const { message, sessionId } = await req.json()
    
    const supabase = await createClient()
    
    // Get current user
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Get cultural dictionary
    const { data: culturalDict } = await supabase
      .from('cultural_dictionary')
      .select('*')
      .eq('is_active', true)
    
    // Get interventions
    const { data: interventions } = await supabase
      .from('interventions')
      .select('*')
      .eq('is_active', true)

    // Analyze the message
    const analysis = analyzeRisk(
      message,
      (culturalDict || []) as CulturalDictionary[],
      (interventions || []) as Intervention[]
    )

    // If crisis detected, create alert
    if (analysis.isCrisis && sessionId) {
      await supabase.from('crisis_alerts').insert({
        session_id: sessionId,
        user_id: user.id,
        severity: 'critical',
        trigger_phrase: analysis.crisisTrigger,
        status: 'pending'
      })
    }

    // Save risk assessment
    if (sessionId) {
      await supabase.from('risk_assessments').insert({
        session_id: sessionId,
        user_id: user.id,
        risk_level: analysis.riskLevel,
        risk_score: analysis.riskScore,
        cultural_flags: analysis.culturalFlags,
        assessment_reason: 'API analysis'
      })
    }

    return NextResponse.json({
      riskLevel: analysis.riskLevel,
      riskScore: analysis.riskScore,
      riskIndicators: analysis.riskIndicators,
      culturalFlags: analysis.culturalFlags,
      isCrisis: analysis.isCrisis,
      suggestedIntervention: analysis.suggestedIntervention
    })
  } catch (error) {
    console.error('Risk analysis error:', error)
    return NextResponse.json({ error: 'Error en el analisis' }, { status: 500 })
  }
}
