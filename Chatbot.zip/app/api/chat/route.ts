import { streamText, convertToModelMessages, UIMessage } from 'ai'
import { createClient } from '@/lib/supabase/server'
import { analyzeRisk, formatIntervention } from '@/lib/risk-analyzer'
import type { CulturalDictionary, Intervention, RiskLevel } from '@/lib/types'

export async function POST(req: Request) {
  const { messages, sessionId }: { messages: UIMessage[]; sessionId?: string } = await req.json()
  
  const supabase = await createClient()
  
  // Get current user
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    return new Response('No autorizado', { status: 401 })
  }

  // Get cultural dictionary for analysis
  const { data: culturalDict } = await supabase
    .from('cultural_dictionary')
    .select('*')
    .eq('is_active', true)
  
  // Get interventions
  const { data: interventions } = await supabase
    .from('interventions')
    .select('*')
    .eq('is_active', true)

  // Get or create session
  let currentSessionId = sessionId
  if (!currentSessionId) {
    const { data: newSession } = await supabase
      .from('chat_sessions')
      .insert({
        user_id: user.id,
        current_risk_level: 'low',
        is_active: true
      })
      .select()
      .single()
    
    currentSessionId = newSession?.id
  }

  // Get last user message for analysis
  const lastUserMessage = messages.filter(m => m.role === 'user').pop()
  const messageText = lastUserMessage?.parts
    ?.filter((p): p is { type: 'text'; text: string } => p.type === 'text')
    .map(p => p.text)
    .join('') || ''

  // Analyze risk
  const analysis = analyzeRisk(
    messageText,
    (culturalDict || []) as CulturalDictionary[],
    (interventions || []) as Intervention[]
  )

  // Handle crisis
  if (analysis.isCrisis) {
    await supabase.from('crisis_alerts').insert({
      session_id: currentSessionId,
      user_id: user.id,
      severity: 'critical',
      trigger_phrase: analysis.crisisTrigger,
      context_messages: messages.slice(-5).map(m => {
        const text = m.parts?.filter((p): p is { type: 'text'; text: string } => p.type === 'text').map(p => p.text).join('') || ''
        return `${m.role}: ${text}`
      }),
      status: 'pending'
    })
  }

  // Save user message
  if (currentSessionId && messageText) {
    await supabase.from('chat_messages').insert({
      session_id: currentSessionId,
      role: 'user',
      content: messageText,
      sentiment_score: analysis.sentimentScore,
      risk_indicators: analysis.riskIndicators
    })
  }

  // Update session risk level
  if (currentSessionId) {
    await supabase
      .from('chat_sessions')
      .update({ current_risk_level: analysis.riskLevel })
      .eq('id', currentSessionId)
  }

  // Save risk assessment
  if (currentSessionId && analysis.riskScore > 0) {
    await supabase.from('risk_assessments').insert({
      session_id: currentSessionId,
      user_id: user.id,
      risk_level: analysis.riskLevel,
      risk_score: analysis.riskScore,
      cultural_flags: analysis.culturalFlags,
      assessment_reason: 'Analisis automatico de mensaje'
    })
  }

  // Save emotional history
  await supabase.from('emotional_history').insert({
    user_id: user.id,
    session_id: currentSessionId,
    anxiety_score: analysis.riskIndicators.filter(i => i.includes('worry') || i.includes('nervousness') || i.includes('fear')).length / 7,
    depression_score: analysis.riskIndicators.filter(i => i.includes('anhedonia') || i.includes('depressed') || i.includes('guilt')).length / 9,
    overall_wellbeing: (1 - analysis.riskScore) * 10,
    dominant_emotions: analysis.riskIndicators.slice(0, 3)
  })

  // Build system prompt based on risk level
  const systemPrompt = buildSystemPrompt(analysis.riskLevel, analysis.isCrisis, analysis.suggestedIntervention)

  const result = streamText({
    model: 'anthropic/claude-sonnet-4-20250514',
    system: systemPrompt,
    messages: await convertToModelMessages(messages),
    maxOutputTokens: 1000,
    onFinish: async ({ text }) => {
      // Save assistant response
      if (currentSessionId) {
        await supabase.from('chat_messages').insert({
          session_id: currentSessionId,
          role: 'assistant',
          content: text
        })
      }
    }
  })

  return result.toUIMessageStreamResponse({
    headers: {
      'X-Session-Id': currentSessionId || '',
      'X-Risk-Level': analysis.riskLevel
    }
  })
}

function buildSystemPrompt(riskLevel: RiskLevel, isCrisis: boolean, intervention: Intervention | null): string {
  const basePrompt = `Eres MenteCalma, un asistente de apoyo emocional para estudiantes universitarios peruanos.

REGLAS FUNDAMENTALES:
- NUNCA des diagnosticos clinicos ni recetes medicamentos
- SIEMPRE muestra empatia y validacion emocional
- Usa lenguaje calido, cercano pero profesional
- Adapta tu lenguaje al contexto universitario peruano
- Responde en español
- Si el estudiante menciona autolesion o suicidio, responde con compasion y urgencia para buscar ayuda profesional

SOBRE TI:
- Eres un companero de apoyo, no un terapeuta
- Tu rol es escuchar, validar y sugerir recursos
- Reconoces cuando algo esta fuera de tu alcance`

  if (isCrisis) {
    return `${basePrompt}

ALERTA: El estudiante ha expresado pensamientos de crisis. 

RESPONDE ASI:
1. Valida sus sentimientos sin minimizarlos
2. Expresa preocupacion genuina
3. Pregunta directamente si esta a salvo
4. Proporciona el numero de linea de crisis: Linea 113 Salud (MINSA)
5. Anima a buscar ayuda profesional inmediata
6. NO lo dejes solo - mantén la conversacion hasta que confirme que buscara ayuda

TONO: Calma, compasion, urgencia sin panico.`
  }

  if (riskLevel === 'high') {
    return `${basePrompt}

NIVEL DE RIESGO: ALTO
El estudiante muestra señales significativas de malestar emocional.

ENFOQUE:
- Prioriza la seguridad y el bienestar
- Sugiere contactar servicios de salud mental de la universidad
- Valida profundamente sus emociones
- Ofrece tecnicas de regulacion emocional si es apropiado
${intervention ? `\nSi es apropiado, sugiere esta tecnica:\n${formatIntervention(intervention)}` : ''}`
  }

  if (riskLevel === 'moderate') {
    return `${basePrompt}

NIVEL DE RIESGO: MODERADO
El estudiante muestra algunas señales de estres o malestar.

ENFOQUE:
- Explora sus preocupaciones con preguntas abiertas
- Ofrece perspectiva y normalizacion cuando sea apropiado
- Sugiere estrategias de afrontamiento
- Menciona los servicios de apoyo disponibles
${intervention ? `\nPuedes ofrecer esta tecnica de bienestar:\n${formatIntervention(intervention)}` : ''}`
  }

  return `${basePrompt}

NIVEL DE RIESGO: BAJO
El estudiante parece estar en un estado emocional estable.

ENFOQUE:
- Conversa de manera natural y amigable
- Fomenta habitos de bienestar preventivos
- Celebra sus logros y fortalezas
- Manten la puerta abierta para futuras conversaciones
${intervention ? `\nPuedes compartir esta practica de bienestar:\n${formatIntervention(intervention)}` : ''}`
}
