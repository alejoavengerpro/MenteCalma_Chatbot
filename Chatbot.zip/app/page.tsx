import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Brain, Heart, Shield, Sparkles, MessageCircle, BarChart3, Users } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <Brain className="h-6 w-6" />
            </div>
            <span className="font-bold text-lg text-foreground">MenteCalma</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login">
              <Button variant="ghost">Iniciar Sesion</Button>
            </Link>
            <Link href="/auth/signup">
              <Button>Comenzar</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-3xl">
          <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10 text-primary mx-auto mb-6">
            <Brain className="h-10 w-10" />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-6 text-balance">
            Tu companero de bienestar emocional universitario
          </h1>
          <p className="text-lg text-muted-foreground mb-8 text-pretty">
            MenteCalma es un chatbot de apoyo emocional diseñado especialmente para estudiantes 
            universitarios peruanos. Te escucha, te acompaña y te ayuda a gestionar el estres academico.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup">
              <Button size="lg" className="w-full sm:w-auto">
                <MessageCircle className="mr-2 h-5 w-5" />
                Comenzar a conversar
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="lg" variant="outline" className="w-full sm:w-auto">
                Ya tengo cuenta
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-5xl">
          <h2 className="text-2xl font-bold text-center text-foreground mb-12">
            ¿Como te ayudamos?
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-accent-foreground mb-4">
                <Heart className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-lg text-foreground mb-2">Escucha empatica</h3>
              <p className="text-muted-foreground text-sm">
                Nuestro chatbot esta entrenado para escucharte sin juicios y validar tus emociones. 
                Puedes expresarte libremente.
              </p>
            </div>

            <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-accent-foreground mb-4">
                <Sparkles className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-lg text-foreground mb-2">Tecnicas basadas en evidencia</h3>
              <p className="text-muted-foreground text-sm">
                Te ofrecemos microintervenciones validadas cientificamente: respiracion, 
                grounding, reestructuracion cognitiva y mas.
              </p>
            </div>

            <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-accent-foreground mb-4">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-lg text-foreground mb-2">Confidencial y seguro</h3>
              <p className="text-muted-foreground text-sm">
                Tu privacidad es nuestra prioridad. Tus conversaciones estan protegidas y 
                solo se usan para brindarte mejor apoyo.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* For Institutions */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="bg-card rounded-2xl border border-border p-8 sm:p-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-4">
                  Para universidades e instituciones
                </h2>
                <p className="text-muted-foreground mb-6">
                  MenteCalma ofrece un panel institucional completo para que los equipos de 
                  bienestar estudiantil puedan monitorear y apoyar a sus estudiantes de manera efectiva.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3 text-foreground">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    Dashboard con metricas de bienestar
                  </li>
                  <li className="flex items-center gap-3 text-foreground">
                    <Users className="h-5 w-5 text-primary" />
                    Gestion de casos por nivel de riesgo
                  </li>
                  <li className="flex items-center gap-3 text-foreground">
                    <Shield className="h-5 w-5 text-primary" />
                    Alertas automaticas de crisis
                  </li>
                </ul>
              </div>
              <div className="flex justify-center">
                <div className="bg-muted rounded-xl p-6 w-full max-w-sm">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-2">Panel Institucional</p>
                    <p className="text-3xl font-bold text-foreground">Disponible</p>
                    <Link href="/auth/login" className="block mt-4">
                      <Button variant="secondary" className="w-full">
                        Acceder al dashboard
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-primary/5">
        <div className="container mx-auto max-w-2xl text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Tu bienestar emocional importa
          </h2>
          <p className="text-muted-foreground mb-8">
            No tienes que enfrentar el estres academico solo. Estamos aqui para acompañarte 
            en tu camino universitario.
          </p>
          <Link href="/auth/signup">
            <Button size="lg">
              Comenzar ahora - Es gratis
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-primary" />
              <span className="font-medium text-foreground">MenteCalma</span>
            </div>
            <p className="text-sm text-muted-foreground text-center">
              Si necesitas ayuda urgente, llama a la Linea 113 Salud (MINSA)
            </p>
            <p className="text-xs text-muted-foreground">
              © 2024 MenteCalma. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
