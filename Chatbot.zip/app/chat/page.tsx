import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { ChatContainer } from '@/components/chat/chat-container'

export default async function ChatPage() {
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect('/auth/login')
  }

  // Get user profile
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  return (
    <main className="h-screen">
      <ChatContainer userName={profile?.full_name || user.email || undefined} />
    </main>
  )
}
