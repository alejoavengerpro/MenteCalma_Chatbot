import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { DashboardHeader } from '@/components/dashboard/dashboard-header'
import { StatsCards } from '@/components/dashboard/stats-cards'
import { AlertsList } from '@/components/dashboard/alerts-list'
import { RiskChart } from '@/components/dashboard/risk-chart'
import { RecentSessions } from '@/components/dashboard/recent-sessions'

export default async function DashboardPage() {
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect('/auth/login')
  }

  // Check if user is authorized
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  if (!profile || (profile.role !== 'psychologist' && profile.role !== 'admin')) {
    redirect('/chat')
  }

  // Fetch dashboard data
  const { data: stats } = await supabase.rpc('get_dashboard_stats')
  
  const { data: pendingAlerts } = await supabase
    .from('crisis_alerts')
    .select(`
      *,
      profiles!crisis_alerts_user_id_fkey(full_name, email)
    `)
    .eq('status', 'pending')
    .order('created_at', { ascending: false })
    .limit(10)

  const { data: recentSessions } = await supabase
    .from('chat_sessions')
    .select(`
      *,
      profiles!chat_sessions_user_id_fkey(full_name, email, university, faculty)
    `)
    .eq('is_active', true)
    .order('started_at', { ascending: false })
    .limit(10)

  const { data: riskDistribution } = await supabase
    .from('chat_sessions')
    .select('current_risk_level')
    .eq('is_active', true)

  // Calculate risk distribution
  const riskCounts = {
    low: riskDistribution?.filter(s => s.current_risk_level === 'low').length || 0,
    moderate: riskDistribution?.filter(s => s.current_risk_level === 'moderate').length || 0,
    high: riskDistribution?.filter(s => s.current_risk_level === 'high').length || 0,
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader userName={profile.full_name || user.email || ''} role={profile.role} />
      
      <main className="container mx-auto px-4 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Panel Institucional</h1>
          <p className="text-muted-foreground">Monitoreo de bienestar estudiantil</p>
        </div>

        <StatsCards 
          totalStudents={stats?.total_students || 0}
          activeSessions={stats?.active_sessions || 0}
          pendingAlerts={pendingAlerts?.length || 0}
          riskDistribution={riskCounts}
        />

        <div className="grid lg:grid-cols-2 gap-6">
          <RiskChart distribution={riskCounts} />
          <AlertsList alerts={pendingAlerts || []} />
        </div>

        <RecentSessions sessions={recentSessions || []} />
      </main>
    </div>
  )
}
