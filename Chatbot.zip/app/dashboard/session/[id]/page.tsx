"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { ArrowLeft, AlertTriangle, Clock, User, MessageCircle, Activity, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  risk_indicators: string[] | null
  sentiment_score: number | null
  created_at: string
}

interface Session {
  id: string
  created_at: string
  ended_at: string | null
  risk_level: "low" | "moderate" | "high"
  total_messages: number
  profiles: {
    display_name: string
    university: string
    career: string
  }
}

interface RiskAssessment {
  id: string
  risk_level: "low" | "moderate" | "high"
  risk_score: number
  clinical_indicators: string[]
  created_at: string
}

export default function SessionDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [session, setSession] = useState<Session | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [assessments, setAssessments] = useState<RiskAssessment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      const supabase = createClient()
      const sessionId = params.id as string

      const [sessionRes, messagesRes, assessmentsRes] = await Promise.all([
        supabase
          .from("chat_sessions")
          .select(`
            *,
            profiles (display_name, university, career)
          `)
          .eq("id", sessionId)
          .single(),
        supabase
          .from("chat_messages")
          .select("*")
          .eq("session_id", sessionId)
          .order("created_at", { ascending: true }),
        supabase
          .from("risk_assessments")
          .select("*")
          .eq("session_id", sessionId)
          .order("created_at", { ascending: false })
      ])

      if (sessionRes.data) setSession(sessionRes.data)
      if (messagesRes.data) setMessages(messagesRes.data)
      if (assessmentsRes.data) setAssessments(assessmentsRes.data)
      setLoading(false)
    }

    fetchData()
  }, [params.id])

  const getRiskColor = (level: string) => {
    switch (level) {
      case "high": return "bg-[var(--risk-high)] text-white"
      case "moderate": return "bg-[var(--risk-moderate)] text-[var(--warning-foreground)]"
      default: return "bg-[var(--risk-low)] text-white"
    }
  }

  const getRiskLabel = (level: string) => {
    switch (level) {
      case "high": return "Alto"
      case "moderate": return "Moderado"
      default: return "Bajo"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          <Skeleton className="h-10 w-48" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Skeleton className="h-96 lg:col-span-2" />
            <Skeleton className="h-96" />
          </div>
        </div>
      </div>
    )
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertTriangle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Sesion no encontrada</p>
          <Button onClick={() => router.push("/dashboard")} className="mt-4">
            Volver al Dashboard
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-xl font-semibold text-foreground">Detalle de Sesion</h1>
              <p className="text-sm text-muted-foreground">
                {new Date(session.created_at).toLocaleDateString("es-PE", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit"
                })}
              </p>
            </div>
            <Badge className={getRiskColor(session.risk_level)}>
              Riesgo {getRiskLabel(session.risk_level)}
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Conversation */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Conversacion
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                          message.role === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted"
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-xs opacity-70">
                            {new Date(message.created_at).toLocaleTimeString("es-PE", {
                              hour: "2-digit",
                              minute: "2-digit"
                            })}
                          </span>
                          {message.risk_indicators && message.risk_indicators.length > 0 && (
                            <Badge variant="outline" className="text-xs border-[var(--risk-high)] text-[var(--risk-high)]">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              {message.risk_indicators.length} indicadores
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Student Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <User className="w-4 h-4" />
                  Estudiante
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Nombre</p>
                  <p className="font-medium">{session.profiles?.display_name || "Anonimo"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Universidad</p>
                  <p className="font-medium">{session.profiles?.university || "No especificada"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Carrera</p>
                  <p className="font-medium">{session.profiles?.career || "No especificada"}</p>
                </div>
              </CardContent>
            </Card>

            {/* Session Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Activity className="w-4 h-4" />
                  Estadisticas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Total mensajes</span>
                  <span className="font-medium">{messages.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Duracion</span>
                  <span className="font-medium">
                    {session.ended_at
                      ? `${Math.round((new Date(session.ended_at).getTime() - new Date(session.created_at).getTime()) / 60000)} min`
                      : "En curso"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Evaluaciones</span>
                  <span className="font-medium">{assessments.length}</span>
                </div>
              </CardContent>
            </Card>

            {/* Risk Assessments */}
            {assessments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Shield className="w-4 h-4" />
                    Evaluaciones de Riesgo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[200px]">
                    <div className="space-y-3">
                      {assessments.map((assessment) => (
                        <div key={assessment.id} className="p-3 bg-muted rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <Badge className={`${getRiskColor(assessment.risk_level)} text-xs`}>
                              {getRiskLabel(assessment.risk_level)}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {Math.round(assessment.risk_score * 100)}%
                            </span>
                          </div>
                          {assessment.clinical_indicators && assessment.clinical_indicators.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {assessment.clinical_indicators.slice(0, 3).map((indicator, i) => (
                                <Badge key={i} variant="outline" className="text-xs">
                                  {indicator}
                                </Badge>
                              ))}
                            </div>
                          )}
                          <p className="text-xs text-muted-foreground mt-2">
                            {new Date(assessment.created_at).toLocaleTimeString("es-PE")}
                          </p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
