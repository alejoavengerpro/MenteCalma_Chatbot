import { updateSession } from '@/lib/supabase/proxy'
import { type NextRequest, NextResponse } from 'next/server'

const protectedRoutes = ['/chat', '/dashboard']
const authRoutes = ['/auth/login', '/auth/signup']

export async function middleware(request: NextRequest) {
  const response = await updateSession(request)
  
  const { pathname } = request.nextUrl
  
  // Check if route needs protection
  const isProtectedRoute = protectedRoutes.some(route => pathname.startsWith(route))
  const isAuthRoute = authRoutes.some(route => pathname.startsWith(route))
  
  // Get user from response cookies
  const supabaseResponse = response
  
  if (isProtectedRoute) {
    // Check for auth token in cookies
    const hasAuthCookie = request.cookies.getAll().some(cookie => 
      cookie.name.includes('auth-token') || cookie.name.includes('sb-')
    )
    
    if (!hasAuthCookie) {
      const loginUrl = new URL('/auth/login', request.url)
      loginUrl.searchParams.set('redirect', pathname)
      return NextResponse.redirect(loginUrl)
    }
  }
  
  return supabaseResponse
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - images - .svg, .png, .jpg, .jpeg, .gif, .webp
     * Feel free to modify this pattern to include more paths.
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
