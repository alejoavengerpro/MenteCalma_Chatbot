'use client'

import { Users, MessageSquare, AlertTriangle, TrendingUp } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface StatsCardsProps {
  totalStudents: number
  activeSessions: number
  pendingAlerts: number
  riskDistribution: {
    low: number
    moderate: number
    high: number
  }
}

export function StatsCards({ totalStudents, activeSessions, pendingAlerts, riskDistribution }: StatsCardsProps) {
  const total = riskDistribution.low + riskDistribution.moderate + riskDistribution.high
  const healthyPercentage = total > 0 
    ? Math.round((riskDistribution.low / total) * 100) 
    : 0

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Estudiantes Registrados
          </CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{totalStudents}</div>
          <p className="text-xs text-muted-foreground mt-1">
            usuarios activos en la plataforma
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Sesiones Activas
          </CardTitle>
          <MessageSquare className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{activeSessions}</div>
          <p className="text-xs text-muted-foreground mt-1">
            conversaciones en curso
          </p>
        </CardContent>
      </Card>

      <Card className={pendingAlerts > 0 ? 'border-destructive/50 bg-destructive/5' : ''}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Alertas Pendientes
          </CardTitle>
          <AlertTriangle className={`h-4 w-4 ${pendingAlerts > 0 ? 'text-destructive' : 'text-muted-foreground'}`} />
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${pendingAlerts > 0 ? 'text-destructive' : 'text-foreground'}`}>
            {pendingAlerts}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {pendingAlerts > 0 ? 'requieren atencion inmediata' : 'sin alertas activas'}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Bienestar General
          </CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{healthyPercentage}%</div>
          <p className="text-xs text-muted-foreground mt-1">
            estudiantes con riesgo bajo
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
