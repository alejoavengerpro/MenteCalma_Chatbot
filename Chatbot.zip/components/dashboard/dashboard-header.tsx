'use client'

import { Brain, LogOut, Bell, Settings } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import type { UserRole } from '@/lib/types'

interface DashboardHeaderProps {
  userName: string
  role: UserRole
}

export function DashboardHeader({ userName, role }: DashboardHeaderProps) {
  const router = useRouter()
  const supabase = createClient()

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/auth/login')
  }

  const roleLabels: Record<UserRole, string> = {
    student: 'Estudiante',
    psychologist: 'Psicologo',
    tutor: 'Tutor',
    admin: 'Administrador'
  }

  return (
    <header className="border-b border-border bg-card sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <Brain className="h-6 w-6" />
            </div>
            <div>
              <span className="font-bold text-foreground">MenteCalma</span>
              <span className="text-xs text-muted-foreground block">Panel Institucional</span>
            </div>
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/dashboard" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
            Dashboard
          </Link>
          <Link href="/dashboard/students" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            Estudiantes
          </Link>
          <Link href="/dashboard/alerts" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            Alertas
          </Link>
          <Link href="/dashboard/reports" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            Reportes
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-destructive text-[10px] text-destructive-foreground flex items-center justify-center">
              3
            </span>
          </Button>
          
          <div className="hidden sm:block text-right">
            <p className="text-sm font-medium text-foreground">{userName}</p>
            <p className="text-xs text-muted-foreground">{roleLabels[role]}</p>
          </div>

          <Button variant="ghost" size="icon" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  )
}
