'use client'

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { MessageSquare, User, Clock, ExternalLink } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { es } from 'date-fns/locale'
import type { RiskLevel } from '@/lib/types'

interface Session {
  id: string
  current_risk_level: RiskLevel
  started_at: string
  is_active: boolean
  profiles?: {
    full_name: string | null
    email: string | null
    university: string | null
    faculty: string | null
  }
}

interface RecentSessionsProps {
  sessions: Session[]
}

export function RecentSessions({ sessions }: RecentSessionsProps) {
  const getRiskBadgeVariant = (level: RiskLevel) => {
    switch (level) {
      case 'high': return 'destructive'
      case 'moderate': return 'outline'
      default: return 'secondary'
    }
  }

  const getRiskLabel = (level: RiskLevel) => {
    switch (level) {
      case 'high': return 'Alto'
      case 'moderate': return 'Moderado'
      default: return 'Bajo'
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Sesiones Recientes</CardTitle>
            <CardDescription>Conversaciones activas con estudiantes</CardDescription>
          </div>
          <Button variant="outline" size="sm">
            Ver todas
            <ExternalLink className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <MessageSquare className="h-12 w-12 text-muted-foreground mb-3" />
            <p className="text-foreground font-medium">Sin sesiones activas</p>
            <p className="text-sm text-muted-foreground">
              Las conversaciones apareceran aqui
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground">Estudiante</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground">Universidad</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground">Nivel de Riesgo</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground">Iniciada</th>
                  <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {sessions.map((session) => (
                  <tr key={session.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
                          <User className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {session.profiles?.full_name || 'Sin nombre'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {session.profiles?.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <p className="text-sm text-foreground">
                        {session.profiles?.university || '-'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {session.profiles?.faculty}
                      </p>
                    </td>
                    <td className="py-3 px-2">
                      <Badge variant={getRiskBadgeVariant(session.current_risk_level)}>
                        {getRiskLabel(session.current_risk_level)}
                      </Badge>
                    </td>
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {formatDistanceToNow(new Date(session.started_at), { 
                          addSuffix: true, 
                          locale: es 
                        })}
                      </div>
                    </td>
                    <td className="py-3 px-2 text-right">
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
