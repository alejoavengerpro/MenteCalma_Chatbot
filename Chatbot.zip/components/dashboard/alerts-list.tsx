'use client'

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { AlertTriangle, Clock, CheckCircle2, Eye } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { es } from 'date-fns/locale'

interface Alert {
  id: string
  severity: 'urgent' | 'critical'
  trigger_phrase: string
  status: 'pending' | 'acknowledged' | 'resolved'
  created_at: string
  profiles?: {
    full_name: string | null
    email: string | null
  }
}

interface AlertsListProps {
  alerts: Alert[]
}

export function AlertsList({ alerts }: AlertsListProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Alertas de Crisis</CardTitle>
            <CardDescription>Casos que requieren atencion inmediata</CardDescription>
          </div>
          {alerts.length > 0 && (
            <Badge variant="destructive" className="text-xs">
              {alerts.length} pendientes
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <CheckCircle2 className="h-12 w-12 text-accent mb-3" />
            <p className="text-foreground font-medium">Sin alertas pendientes</p>
            <p className="text-sm text-muted-foreground">
              Todos los casos han sido atendidos
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className="flex items-start gap-3 p-3 rounded-lg border border-destructive/30 bg-destructive/5"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-destructive/20">
                  <AlertTriangle className="h-5 w-5 text-destructive" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-foreground truncate">
                      {alert.profiles?.full_name || alert.profiles?.email || 'Estudiante'}
                    </span>
                    <Badge 
                      variant={alert.severity === 'critical' ? 'destructive' : 'outline'}
                      className="text-[10px]"
                    >
                      {alert.severity === 'critical' ? 'CRITICO' : 'URGENTE'}
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-muted-foreground line-clamp-1">
                    Trigger: "{alert.trigger_phrase}"
                  </p>
                  
                  <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {formatDistanceToNow(new Date(alert.created_at), { 
                      addSuffix: true, 
                      locale: es 
                    })}
                  </div>
                </div>

                <Button size="sm" variant="destructive">
                  <Eye className="h-4 w-4 mr-1" />
                  Ver
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
