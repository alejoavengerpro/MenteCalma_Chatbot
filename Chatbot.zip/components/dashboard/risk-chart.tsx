'use client'

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts'

interface RiskChartProps {
  distribution: {
    low: number
    moderate: number
    high: number
  }
}

export function RiskChart({ distribution }: RiskChartProps) {
  const data = [
    { name: 'Bajo', value: distribution.low, color: 'var(--risk-low)' },
    { name: 'Moderado', value: distribution.moderate, color: 'var(--risk-moderate)' },
    { name: 'Alto', value: distribution.high, color: 'var(--risk-high)' },
  ]

  const total = distribution.low + distribution.moderate + distribution.high

  if (total === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Distribucion de Riesgo</CardTitle>
          <CardDescription>Niveles de riesgo en sesiones activas</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[300px]">
          <p className="text-muted-foreground text-center">
            No hay sesiones activas para mostrar
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribucion de Riesgo</CardTitle>
        <CardDescription>Niveles de riesgo en sesiones activas</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={2}
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: number) => [`${value} sesiones`, 'Cantidad']}
                contentStyle={{
                  backgroundColor: 'var(--card)',
                  border: '1px solid var(--border)',
                  borderRadius: '8px'
                }}
              />
              <Legend 
                verticalAlign="bottom" 
                height={36}
                formatter={(value) => <span className="text-foreground text-sm">{value}</span>}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-border">
          <div className="text-center">
            <div className="text-2xl font-bold text-foreground" style={{ color: 'var(--risk-low)' }}>
              {distribution.low}
            </div>
            <p className="text-xs text-muted-foreground">Riesgo Bajo</p>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold" style={{ color: 'var(--risk-moderate)' }}>
              {distribution.moderate}
            </div>
            <p className="text-xs text-muted-foreground">Riesgo Moderado</p>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold" style={{ color: 'var(--risk-high)' }}>
              {distribution.high}
            </div>
            <p className="text-xs text-muted-foreground">Riesgo Alto</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
