'use client'

import { Brain, Heart, Shield, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface WelcomeScreenProps {
  userName?: string
  suggestions: string[]
  onSuggestionClick: (text: string) => void
}

export function WelcomeScreen({ userName, suggestions, onSuggestionClick }: WelcomeScreenProps) {
  return (
    <div className="flex h-full flex-col items-center justify-center px-4 py-8">
      <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10 text-primary mb-6">
        <Brain className="h-10 w-10" />
      </div>
      
      <h2 className="text-2xl font-semibold text-foreground text-center mb-2">
        {userName ? `Hola, ${userName.split(' ')[0]}` : 'Bienvenido a MenteCalma'}
      </h2>
      
      <p className="text-muted-foreground text-center max-w-md mb-8">
        Estoy aqui para escucharte y acompañarte. Puedes contarme como te sientes hoy.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8 max-w-2xl w-full">
        <div className="flex flex-col items-center gap-2 rounded-xl bg-card border border-border p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <Heart className="h-5 w-5" />
          </div>
          <span className="text-sm font-medium text-foreground">Empatico</span>
          <span className="text-xs text-muted-foreground text-center">Escucha sin juicios</span>
        </div>
        
        <div className="flex flex-col items-center gap-2 rounded-xl bg-card border border-border p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <Shield className="h-5 w-5" />
          </div>
          <span className="text-sm font-medium text-foreground">Confidencial</span>
          <span className="text-xs text-muted-foreground text-center">Tu privacidad importa</span>
        </div>
        
        <div className="flex flex-col items-center gap-2 rounded-xl bg-card border border-border p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <Sparkles className="h-5 w-5" />
          </div>
          <span className="text-sm font-medium text-foreground">Basado en evidencia</span>
          <span className="text-xs text-muted-foreground text-center">Tecnicas validadas</span>
        </div>
      </div>

      <div className="w-full max-w-md">
        <p className="text-sm text-muted-foreground text-center mb-3">
          Sugerencias para empezar:
        </p>
        <div className="flex flex-wrap gap-2 justify-center">
          {suggestions.map((suggestion, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              className="text-xs rounded-full"
              onClick={() => onSuggestionClick(suggestion)}
            >
              {suggestion}
            </Button>
          ))}
        </div>
      </div>

      <p className="text-xs text-muted-foreground text-center mt-8 max-w-sm">
        Recuerda: Soy un asistente de apoyo, no un profesional de salud mental. 
        Si necesitas ayuda urgente, contacta la Linea 113 Salud.
      </p>
    </div>
  )
}
