'use client'

import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import { useEffect, useRef, useState } from 'react'
import { ChatMessage } from './chat-message'
import { ChatInput } from './chat-input'
import { ChatHeader } from './chat-header'
import { WelcomeScreen } from './welcome-screen'
import { cn } from '@/lib/utils'

interface ChatContainerProps {
  userName?: string
}

export function ChatContainer({ userName }: ChatContainerProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [sessionId, setSessionId] = useState<string | null>(null)

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({
      api: '/api/chat',
      headers: sessionId ? { 'X-Session-Id': sessionId } : undefined,
    }),
  })

  const isStreaming = status === 'streaming' || status === 'submitted'

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSend = (text: string) => {
    sendMessage({ text })
  }

  const suggestedPrompts = [
    'Me siento estresado por los examenes',
    'Ultimamente me cuesta concentrarme',
    'Necesito hablar con alguien',
    'Como puedo manejar la ansiedad?'
  ]

  return (
    <div className="flex h-full flex-col bg-background">
      <ChatHeader userName={userName} />
      
      <div className="flex-1 overflow-y-auto">
        {messages.length === 0 ? (
          <WelcomeScreen
            userName={userName}
            suggestions={suggestedPrompts}
            onSuggestionClick={handleSend}
          />
        ) : (
          <div className="flex flex-col py-4">
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
            
            {isStreaming && messages[messages.length - 1]?.role === 'user' && (
              <div className="flex items-start gap-3 px-4 py-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                  <div className="flex gap-1">
                    <span className="h-2 w-2 rounded-full bg-current animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="h-2 w-2 rounded-full bg-current animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="h-2 w-2 rounded-full bg-current animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      <ChatInput
        onSend={handleSend}
        isLoading={isStreaming}
      />
    </div>
  )
}
