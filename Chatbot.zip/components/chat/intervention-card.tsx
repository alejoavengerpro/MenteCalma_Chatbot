"use client"

import { useState } from "react"
import { Sparkles, ChevronDown, ChevronUp, CheckCircle2, Heart } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface InterventionCardProps {
  title: string
  category: string
  content: string
  steps?: string[]
  onComplete?: () => void
}

export function InterventionCard({ 
  title, 
  category, 
  content, 
  steps = [],
  onComplete 
}: InterventionCardProps) {
  const [expanded, setExpanded] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)

  const getCategoryColor = (cat: string) => {
    switch (cat.toLowerCase()) {
      case "respiracion":
        return "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300"
      case "grounding":
        return "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300"
      case "reestructuracion":
        return "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
      case "activacion":
        return "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300"
      case "mindfulness":
        return "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300"
      default:
        return "bg-primary/10 text-primary"
    }
  }

  const handleStepComplete = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setCompleted(true)
      onComplete?.()
    }
  }

  return (
    <Card className={cn(
      "transition-all duration-300 border-2",
      completed 
        ? "border-[var(--success)] bg-[var(--success)]/5" 
        : "border-primary/20 hover:border-primary/40"
    )}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className={cn(
            "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
            completed ? "bg-[var(--success)]" : "bg-primary/10"
          )}>
            {completed ? (
              <CheckCircle2 className="w-5 h-5 text-white" />
            ) : (
              <Sparkles className="w-5 h-5 text-primary" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={cn(
                "text-xs px-2 py-0.5 rounded-full font-medium",
                getCategoryColor(category)
              )}>
                {category}
              </span>
              {completed && (
                <span className="text-xs text-[var(--success)] flex items-center gap-1">
                  <Heart className="w-3 h-3" /> Completado
                </span>
              )}
            </div>
            
            <h4 className="font-medium text-foreground mt-1">{title}</h4>
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{content}</p>
            
            {steps.length > 0 && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-2 h-auto p-0 text-primary hover:text-primary/80"
                  onClick={() => setExpanded(!expanded)}
                >
                  {expanded ? (
                    <>
                      <ChevronUp className="w-4 h-4 mr-1" /> Ocultar pasos
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-4 h-4 mr-1" /> Ver {steps.length} pasos
                    </>
                  )}
                </Button>
                
                {expanded && !completed && (
                  <div className="mt-4 space-y-3">
                    {steps.map((step, index) => (
                      <div 
                        key={index}
                        className={cn(
                          "flex items-start gap-3 p-3 rounded-lg transition-all",
                          index === currentStep 
                            ? "bg-primary/10 border border-primary/30" 
                            : index < currentStep 
                              ? "bg-[var(--success)]/10 border border-[var(--success)]/30"
                              : "bg-muted/50"
                        )}
                      >
                        <div className={cn(
                          "w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium shrink-0",
                          index === currentStep
                            ? "bg-primary text-primary-foreground"
                            : index < currentStep
                              ? "bg-[var(--success)] text-white"
                              : "bg-muted-foreground/20 text-muted-foreground"
                        )}>
                          {index < currentStep ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            index + 1
                          )}
                        </div>
                        <p className={cn(
                          "text-sm flex-1",
                          index <= currentStep ? "text-foreground" : "text-muted-foreground"
                        )}>
                          {step}
                        </p>
                      </div>
                    ))}
                    
                    <Button 
                      className="w-full mt-4"
                      onClick={handleStepComplete}
                    >
                      {currentStep < steps.length - 1 
                        ? `Siguiente paso (${currentStep + 2}/${steps.length})`
                        : "Completar ejercicio"
                      }
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
