-- =====================================================
-- DATOS INICIALES: Intervenciones y Diccionario Cultural
-- =====================================================

-- Intervenciones basadas en evidencia (MABE)
INSERT INTO public.interventions (name, type, description, instructions, risk_levels, duration_minutes, evidence_base) VALUES
(
  'Respiracion Diafragmatica 4-7-8',
  'breathing',
  'Tecnica de respiracion profunda para reducir la ansiedad y activar el sistema nervioso parasimpatico.',
  '{"steps": ["Inhala por la nariz contando hasta 4", "Manten el aire contando hasta 7", "Exhala lentamente por la boca contando hasta 8", "Repite el ciclo 4 veces"]}',
  ARRAY['low', 'moderate', 'high'],
  5,
  'Tecnica validada clinicamente para reduccion de ansiedad (Jerath et al., 2015)'
),
(
  'Grounding 5-4-3-2-1',
  'grounding',
  'Tecnica de anclaje sensorial para momentos de ansiedad intensa o disociacion.',
  '{"steps": ["Nombra 5 cosas que puedas VER a tu alrededor", "Nombra 4 cosas que puedas TOCAR", "Nombra 3 cosas que puedas ESCUCHAR", "Nombra 2 cosas que puedas OLER", "Nombra 1 cosa que puedas SABOREAR"]}',
  ARRAY['moderate', 'high', 'critical'],
  5,
  'Tecnica de mindfulness basada en evidencia para manejo de crisis (Keng et al., 2011)'
),
(
  'Reestructuracion Cognitiva Simple',
  'cognitive',
  'Identifica y cuestiona pensamientos negativos automaticos.',
  '{"steps": ["Identifica el pensamiento negativo", "Preguntate: Es este pensamiento 100% verdadero?", "Que evidencia tengo a favor y en contra?", "Cual seria una forma mas equilibrada de ver esta situacion?", "Como me sentiria si pensara de esta forma alternativa?"]}',
  ARRAY['low', 'moderate'],
  10,
  'Tecnica central de la Terapia Cognitivo-Conductual (Beck, 1979)'
),
(
  'Relajacion Muscular Progresiva',
  'mindfulness',
  'Tecnica de relajacion que consiste en tensar y relajar grupos musculares.',
  '{"steps": ["Encuentra una posicion comoda", "Cierra los ojos y respira profundo", "Comienza por los pies: tensa los musculos por 5 segundos", "Suelta y siente la relajacion por 10 segundos", "Continua subiendo: piernas, abdomen, pecho, brazos, cara", "Al terminar, respira profundo y abre los ojos lentamente"]}',
  ARRAY['low', 'moderate'],
  15,
  'Tecnica de Jacobson validada para reduccion de estres (Jacobson, 1938)'
),
(
  'Activacion Conductual Mini',
  'behavioral',
  'Planifica una actividad pequena y agradable para mejorar el animo.',
  '{"steps": ["Piensa en una actividad pequena que antes disfrutabas", "Puede ser algo simple: escuchar musica, caminar, llamar a alguien", "Comprometete a hacerla en las proximas 24 horas", "Despues de hacerla, nota como te sientes"]}',
  ARRAY['low', 'moderate'],
  5,
  'Componente de la Terapia de Activacion Conductual (Martell et al., 2010)'
),
(
  'Mindfulness del Momento Presente',
  'mindfulness',
  'Practica de atencion plena para reducir la rumiacion y preocupacion.',
  '{"steps": ["Detente un momento y cierra los ojos si puedes", "Enfoca tu atencion en tu respiracion", "Nota el aire entrando y saliendo", "Si tu mente se distrae, gentilmente regresa a la respiracion", "Continua por 2-3 minutos"]}',
  ARRAY['low', 'moderate', 'high'],
  3,
  'Practica basada en MBSR (Kabat-Zinn, 1990)'
),
(
  'Tecnica STOP para Crisis',
  'grounding',
  'Tecnica rapida para momentos de alta ansiedad o panico.',
  '{"steps": ["S - STOP: Detente, no reacciones impulsivamente", "T - TAKE a breath: Toma una respiracion profunda", "O - OBSERVE: Observa lo que esta pasando en tu cuerpo y mente", "P - PROCEED: Procede con una accion consciente y calmada"]}',
  ARRAY['high', 'critical'],
  2,
  'Tecnica de DBT para regulacion emocional (Linehan, 1993)'
),
(
  'Diario de Gratitud Express',
  'cognitive',
  'Ejercicio rapido para cambiar el enfoque mental hacia lo positivo.',
  '{"steps": ["Piensa en 3 cosas por las que estas agradecido hoy", "Pueden ser cosas pequenas: tu cafe, el clima, un mensaje", "Escribe o di en voz alta por que cada una te hace sentir bien", "Nota como cambia tu estado de animo"]}',
  ARRAY['low'],
  3,
  'Intervencion de psicologia positiva (Emmons & McCullough, 2003)'
);

-- Diccionario cultural peruano (ADCU)
INSERT INTO public.cultural_dictionary (expression, normalized_meaning, emotional_category, severity_weight, region, context) VALUES
-- Expresiones de ansiedad/preocupacion
('palteado', 'preocupado, ansioso, incomodo', 'anxiety', 0.6, 'Peru', ARRAY['informal', 'juvenil']),
('paltear', 'sentir ansiedad o incomodidad', 'anxiety', 0.6, 'Peru', ARRAY['informal', 'juvenil']),
('me palteo', 'me siento ansioso o incomodo', 'anxiety', 0.6, 'Peru', ARRAY['informal', 'juvenil']),
('estoy palta', 'me siento muy ansioso o incomodo', 'anxiety', 0.7, 'Peru', ARRAY['informal', 'juvenil']),
('que palta', 'que situacion tan incomoda', 'anxiety', 0.5, 'Peru', ARRAY['informal', 'juvenil']),
('me da roche', 'me da verguenza, ansiedad social', 'social_anxiety', 0.5, 'Peru', ARRAY['informal']),
('rochoso', 'vergonzoso, que causa ansiedad social', 'social_anxiety', 0.4, 'Peru', ARRAY['informal']),
('estoy manija', 'estoy muy ansioso o estresado', 'anxiety', 0.7, 'Peru', ARRAY['informal', 'juvenil']),
('tengo la mente a mil', 'pensamientos acelerados, ansiedad', 'anxiety', 0.6, 'Peru', ARRAY['informal']),

-- Expresiones de tristeza/depresion
('estoy bajoneado', 'me siento deprimido, triste', 'depression', 0.7, 'Peru', ARRAY['informal']),
('ando bajoneado', 'estoy pasando por un momento de tristeza', 'depression', 0.7, 'Peru', ARRAY['informal']),
('me siento misio', 'me siento vacio, sin recursos emocionales', 'depression', 0.6, 'Peru', ARRAY['informal']),
('estoy aguja', 'me siento muy mal, sin recursos', 'depression', 0.7, 'Peru', ARRAY['informal']),
('me siento del carajo', 'me siento muy mal', 'depression', 0.8, 'Peru', ARRAY['informal', 'fuerte']),
('ando como zombie', 'me siento sin energia, desconectado', 'depression', 0.7, 'Peru', ARRAY['informal']),
('no tengo ganas de nada', 'anhedonia, falta de motivacion', 'depression', 0.8, 'Peru', ARRAY['comun']),
('todo me vale', 'apatia, falta de interes', 'depression', 0.7, 'Peru', ARRAY['informal']),

-- Expresiones de estres academico
('estoy quemado', 'burnout, agotamiento extremo', 'burnout', 0.8, 'Peru', ARRAY['informal', 'academico']),
('me estan jodiendo los cursos', 'estres academico intenso', 'academic_stress', 0.7, 'Peru', ARRAY['informal', 'academico']),
('voy a jalar', 'miedo a reprobar, ansiedad academica', 'academic_anxiety', 0.6, 'Peru', ARRAY['academico']),
('me van a botar', 'miedo a expulsion, ansiedad severa', 'academic_anxiety', 0.8, 'Peru', ARRAY['academico']),
('estoy hasta el cuello', 'sobrecarga, estres extremo', 'stress', 0.7, 'Peru', ARRAY['informal']),
('no me da el tiempo', 'estres por presion de tiempo', 'stress', 0.5, 'Peru', ARRAY['comun']),
('me estoy sacando la mugre', 'trabajando excesivamente, agotamiento', 'burnout', 0.7, 'Peru', ARRAY['informal']),

-- Expresiones de aislamiento social
('me siento solo', 'soledad, aislamiento', 'loneliness', 0.7, 'Peru', ARRAY['comun']),
('nadie me entiende', 'sentimiento de incomprension', 'loneliness', 0.7, 'Peru', ARRAY['comun']),
('no tengo patas', 'no tengo amigos, aislamiento', 'loneliness', 0.6, 'Peru', ARRAY['informal', 'juvenil']),
('me siento un cero a la izquierda', 'baja autoestima, insignificancia', 'low_self_esteem', 0.7, 'Peru', ARRAY['comun']),
('soy un fracaso', 'pensamiento autocritico severo', 'low_self_esteem', 0.8, 'Peru', ARRAY['comun']),

-- Expresiones de crisis/urgencia
('ya no puedo mas', 'agotamiento extremo, posible crisis', 'crisis', 0.9, 'Peru', ARRAY['comun', 'urgente']),
('quiero desaparecer', 'posible ideacion suicida', 'suicidal_ideation', 0.95, 'Peru', ARRAY['urgente']),
('para que seguir', 'posible ideacion suicida', 'suicidal_ideation', 0.95, 'Peru', ARRAY['urgente']),
('no vale la pena', 'desesperanza, posible ideacion', 'hopelessness', 0.85, 'Peru', ARRAY['urgente']),
('estoy harto de todo', 'frustracion extrema, posible crisis', 'crisis', 0.8, 'Peru', ARRAY['comun']),
('me quiero morir', 'ideacion suicida explicita', 'suicidal_ideation', 1.0, 'Peru', ARRAY['urgente', 'critico']),
('no quiero seguir viviendo', 'ideacion suicida explicita', 'suicidal_ideation', 1.0, 'Peru', ARRAY['urgente', 'critico']),

-- Expresiones de autocuidado negativo
('no puedo dormir', 'insomnio, alteracion del sueno', 'sleep_issues', 0.6, 'Peru', ARRAY['comun']),
('no tengo hambre', 'perdida de apetito', 'appetite_issues', 0.5, 'Peru', ARRAY['comun']),
('como por comer', 'alimentacion sin placer', 'appetite_issues', 0.5, 'Peru', ARRAY['comun']),
('me da flojera levantarme', 'falta de energia, posible depresion', 'fatigue', 0.6, 'Peru', ARRAY['comun']),
('duermo todo el dia', 'hipersomnia, posible depresion', 'sleep_issues', 0.7, 'Peru', ARRAY['comun']);
