-- =====================================================
-- SCHEMA: Chatbot de Deteccion de Ansiedad y Depresion
-- =====================================================

-- Tabla de perfiles de usuarios (estudiantes y psicologos)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'psychologist', 'admin')),
  student_code TEXT,
  faculty TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de sesiones de chat
CREATE TABLE IF NOT EXISTS public.chat_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'completed', 'escalated')),
  overall_risk_level TEXT CHECK (overall_risk_level IN ('low', 'moderate', 'high', 'critical')),
  notes TEXT
);

-- Tabla de mensajes del chat
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  -- Analisis del mensaje
  sentiment_score DECIMAL(3,2),
  anxiety_indicators JSONB,
  depression_indicators JSONB,
  risk_level TEXT CHECK (risk_level IN ('low', 'moderate', 'high', 'critical')),
  -- Metadata adicional
  metadata JSONB DEFAULT '{}'::JSONB
);

-- Tabla de evaluaciones de riesgo
CREATE TABLE IF NOT EXISTS public.risk_assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  -- Scores clinicos
  phq9_score INTEGER,
  gad7_score INTEGER,
  -- Clasificacion de riesgo
  anxiety_level TEXT CHECK (anxiety_level IN ('minimal', 'mild', 'moderate', 'severe')),
  depression_level TEXT CHECK (depression_level IN ('minimal', 'mild', 'moderate', 'severe')),
  overall_risk TEXT NOT NULL CHECK (overall_risk IN ('low', 'moderate', 'high', 'critical')),
  -- Indicadores detectados
  detected_symptoms JSONB,
  behavioral_patterns JSONB,
  cultural_context JSONB,
  -- Recomendaciones
  recommended_interventions JSONB,
  escalation_required BOOLEAN DEFAULT FALSE,
  escalation_reason TEXT
);

-- Tabla de intervenciones (MABE)
CREATE TABLE IF NOT EXISTS public.interventions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('breathing', 'grounding', 'cognitive', 'behavioral', 'mindfulness')),
  description TEXT NOT NULL,
  instructions JSONB NOT NULL,
  risk_levels TEXT[] NOT NULL,
  duration_minutes INTEGER,
  evidence_base TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de intervenciones aplicadas
CREATE TABLE IF NOT EXISTS public.applied_interventions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
  intervention_id UUID NOT NULL REFERENCES public.interventions(id) ON DELETE CASCADE,
  applied_at TIMESTAMPTZ DEFAULT NOW(),
  user_feedback TEXT,
  effectiveness_rating INTEGER CHECK (effectiveness_rating BETWEEN 1 AND 5)
);

-- Tabla de alertas de crisis (SPCP)
CREATE TABLE IF NOT EXISTS public.crisis_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  alert_type TEXT NOT NULL CHECK (alert_type IN ('suicidal_ideation', 'self_harm', 'severe_crisis', 'immediate_danger')),
  trigger_message TEXT,
  confidence_score DECIMAL(3,2),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'acknowledged', 'in_progress', 'resolved')),
  assigned_to UUID REFERENCES public.profiles(id),
  resolved_at TIMESTAMPTZ,
  resolution_notes TEXT
);

-- Tabla de historial emocional (DECEL)
CREATE TABLE IF NOT EXISTS public.emotional_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  recorded_at TIMESTAMPTZ DEFAULT NOW(),
  anxiety_score DECIMAL(3,2),
  depression_score DECIMAL(3,2),
  mood_score DECIMAL(3,2),
  energy_level DECIMAL(3,2),
  stress_level DECIMAL(3,2),
  sleep_quality DECIMAL(3,2),
  notes TEXT
);

-- Tabla de diccionario cultural peruano (ADCU)
CREATE TABLE IF NOT EXISTS public.cultural_dictionary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  expression TEXT NOT NULL UNIQUE,
  normalized_meaning TEXT NOT NULL,
  emotional_category TEXT,
  severity_weight DECIMAL(3,2),
  region TEXT,
  context TEXT[]
);

-- Habilitar RLS en todas las tablas
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.risk_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.interventions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applied_interventions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crisis_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.emotional_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cultural_dictionary ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- POLITICAS RLS
-- =====================================================

-- Profiles: usuarios pueden ver y editar su propio perfil
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Profiles: psicologos y admins pueden ver todos los perfiles
CREATE POLICY "profiles_select_staff" ON public.profiles FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );

-- Chat Sessions: estudiantes ven sus propias sesiones
CREATE POLICY "sessions_select_own" ON public.chat_sessions FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "sessions_insert_own" ON public.chat_sessions FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "sessions_update_own" ON public.chat_sessions FOR UPDATE USING (user_id = auth.uid());

-- Chat Sessions: staff puede ver todas las sesiones
CREATE POLICY "sessions_select_staff" ON public.chat_sessions FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );

-- Chat Messages: usuarios ven mensajes de sus sesiones
CREATE POLICY "messages_select_own" ON public.chat_messages FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.chat_sessions s 
      WHERE s.id = session_id 
      AND s.user_id = auth.uid()
    )
  );
CREATE POLICY "messages_insert_own" ON public.chat_messages FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.chat_sessions s 
      WHERE s.id = session_id 
      AND s.user_id = auth.uid()
    )
  );

-- Chat Messages: staff puede ver todos los mensajes
CREATE POLICY "messages_select_staff" ON public.chat_messages FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );

-- Risk Assessments: usuarios ven sus propias evaluaciones
CREATE POLICY "assessments_select_own" ON public.risk_assessments FOR SELECT USING (user_id = auth.uid());

-- Risk Assessments: staff puede ver y crear evaluaciones
CREATE POLICY "assessments_select_staff" ON public.risk_assessments FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );
CREATE POLICY "assessments_insert_staff" ON public.risk_assessments FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );

-- Interventions: todos pueden ver las intervenciones
CREATE POLICY "interventions_select_all" ON public.interventions FOR SELECT USING (true);

-- Applied Interventions: usuarios ven sus propias intervenciones aplicadas
CREATE POLICY "applied_select_own" ON public.applied_interventions FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.chat_sessions s 
      WHERE s.id = session_id 
      AND s.user_id = auth.uid()
    )
  );
CREATE POLICY "applied_insert_own" ON public.applied_interventions FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.chat_sessions s 
      WHERE s.id = session_id 
      AND s.user_id = auth.uid()
    )
  );

-- Crisis Alerts: staff puede ver y gestionar alertas
CREATE POLICY "alerts_select_staff" ON public.crisis_alerts FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );
CREATE POLICY "alerts_update_staff" ON public.crisis_alerts FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );

-- Emotional History: usuarios ven su propio historial
CREATE POLICY "history_select_own" ON public.emotional_history FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "history_insert_own" ON public.emotional_history FOR INSERT WITH CHECK (user_id = auth.uid());

-- Emotional History: staff puede ver todo el historial
CREATE POLICY "history_select_staff" ON public.emotional_history FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('psychologist', 'admin')
    )
  );

-- Cultural Dictionary: todos pueden leer
CREATE POLICY "dictionary_select_all" ON public.cultural_dictionary FOR SELECT USING (true);

-- =====================================================
-- TRIGGER PARA CREAR PERFIL AUTOMATICAMENTE
-- =====================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NULL),
    COALESCE(NEW.raw_user_meta_data ->> 'role', 'student')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- =====================================================
-- INDICES PARA PERFORMANCE
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_chat_sessions_user_id ON public.chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_status ON public.chat_sessions(status);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id ON public.chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON public.chat_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_risk_assessments_user_id ON public.risk_assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_risk_assessments_overall_risk ON public.risk_assessments(overall_risk);
CREATE INDEX IF NOT EXISTS idx_crisis_alerts_status ON public.crisis_alerts(status);
CREATE INDEX IF NOT EXISTS idx_crisis_alerts_created_at ON public.crisis_alerts(created_at);
CREATE INDEX IF NOT EXISTS idx_emotional_history_user_id ON public.emotional_history(user_id);
CREATE INDEX IF NOT EXISTS idx_emotional_history_recorded_at ON public.emotional_history(recorded_at);
