-- Function to get dashboard statistics
CREATE OR REPLACE FUNCTION get_dashboard_stats()
RETURNS JSON AS $$
DECLARE
  result JSON;
BEGIN
  SELECT json_build_object(
    'total_students', (
      SELECT COUNT(*) FROM profiles WHERE role = 'student'
    ),
    'active_sessions', (
      SELECT COUNT(*) FROM chat_sessions WHERE is_active = true
    ),
    'pending_alerts', (
      SELECT COUNT(*) FROM crisis_alerts WHERE status = 'pending'
    ),
    'total_messages', (
      SELECT COUNT(*) FROM chat_messages
    ),
    'risk_distribution', (
      SELECT json_build_object(
        'low', COUNT(*) FILTER (WHERE current_risk_level = 'low'),
        'moderate', COUNT(*) FILTER (WHERE current_risk_level = 'moderate'),
        'high', COUNT(*) FILTER (WHERE current_risk_level = 'high')
      )
      FROM chat_sessions WHERE is_active = true
    )
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION get_dashboard_stats() TO authenticated;
