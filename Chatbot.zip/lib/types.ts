export type RiskLevel = 'low' | 'moderate' | 'high'
export type UserRole = 'student' | 'psychologist' | 'tutor' | 'admin'

export interface Profile {
  id: string
  email: string
  full_name: string | null
  role: UserRole
  university: string | null
  faculty: string | null
  created_at: string
  last_active: string | null
}

export interface ChatSession {
  id: string
  user_id: string
  started_at: string
  ended_at: string | null
  current_risk_level: RiskLevel
  is_active: boolean
}

export interface ChatMessage {
  id: string
  session_id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  sentiment_score: number | null
  risk_indicators: string[] | null
  created_at: string
}

export interface RiskAssessment {
  id: string
  session_id: string
  user_id: string
  risk_level: RiskLevel
  risk_score: number
  phq9_indicators: string[] | null
  gad7_indicators: string[] | null
  cultural_flags: string[] | null
  behavioral_flags: string[] | null
  assessment_reason: string
  created_at: string
}

export interface Intervention {
  id: string
  name: string
  description: string
  category: 'breathing' | 'grounding' | 'cognitive' | 'behavioral' | 'mindfulness' | 'journaling'
  min_risk_level: RiskLevel
  max_risk_level: RiskLevel
  duration_minutes: number
  instructions: string
  evidence_source: string | null
  is_active: boolean
}

export interface CrisisAlert {
  id: string
  session_id: string
  user_id: string
  severity: 'urgent' | 'critical'
  trigger_phrase: string
  context_messages: string[] | null
  status: 'pending' | 'acknowledged' | 'resolved'
  assigned_to: string | null
  created_at: string
  resolved_at: string | null
  resolution_notes: string | null
}

export interface EmotionalHistory {
  id: string
  user_id: string
  recorded_at: string
  anxiety_score: number
  depression_score: number
  overall_wellbeing: number
  dominant_emotions: string[] | null
  session_id: string | null
}

export interface CulturalDictionary {
  id: string
  expression: string
  normalized_meaning: string
  emotional_category: string
  intensity_modifier: number
  region: string | null
  is_active: boolean
}

export interface AnalysisResult {
  sentimentScore: number
  riskLevel: RiskLevel
  riskScore: number
  riskIndicators: string[]
  culturalFlags: string[]
  suggestedIntervention: Intervention | null
  isCrisis: boolean
  crisisTrigger: string | null
}

export interface DashboardStats {
  totalStudents: number
  activeSessions: number
  pendingAlerts: number
  riskDistribution: {
    low: number
    moderate: number
    high: number
  }
  recentTrend: 'improving' | 'stable' | 'declining'
}
