import type { RiskLevel, AnalysisResult, CulturalDictionary, Intervention } from './types'

// PHQ-9 keywords for depression detection
const PHQ9_INDICATORS = {
  anhedonia: ['no me interesa', 'no disfruto', 'nada me emociona', 'todo me da igual', 'sin ganas'],
  depressed_mood: ['triste', 'deprimido', 'vacio', 'sin esperanza', 'desesperado', 'infeliz'],
  sleep: ['no puedo dormir', 'insomnio', 'duermo mucho', 'fatiga', 'cansado todo el tiempo'],
  energy: ['sin energia', 'agotado', 'exhausto', 'no tengo fuerzas'],
  appetite: ['sin apetito', 'como mucho', 'no como', 'perdiendo peso'],
  guilt: ['me siento culpable', 'soy un fracaso', 'decepciono', 'inutil'],
  concentration: ['no puedo concentrarme', 'no pienso bien', 'confundido', 'olvidadizo'],
  psychomotor: ['muy lento', 'inquieto', 'no puedo quedarme quieto'],
  suicidal: ['mejor muerto', 'hacerme dano', 'no quiero vivir', 'suicidio', 'acabar con todo']
}

// GAD-7 keywords for anxiety detection  
const GAD7_INDICATORS = {
  nervousness: ['nervioso', 'ansioso', 'tenso', 'preocupado', 'angustiado'],
  uncontrollable_worry: ['no puedo dejar de preocuparme', 'pensamientos intrusivos', 'rumiar'],
  excessive_worry: ['me preocupo demasiado', 'pienso mucho', 'obsesionado'],
  relaxation: ['no puedo relajarme', 'siempre alerta', 'no descanso'],
  restlessness: ['inquieto', 'no puedo estar quieto', 'nervios'],
  irritability: ['irritable', 'enojado', 'me molesta todo', 'frustrado'],
  fear: ['miedo', 'panico', 'terror', 'algo malo va a pasar', 'catastrofe']
}

// Crisis keywords - highest priority
const CRISIS_KEYWORDS = [
  'suicidio', 'suicidarme', 'matarme', 'quitarme la vida',
  'mejor muerto', 'no quiero vivir', 'acabar con todo',
  'hacerme dano', 'cortarme', 'autolesion',
  'no vale la pena', 'nadie me extrañaria',
  'plan para', 'tengo un plan', 'he pensado como'
]

export function analyzeRisk(
  message: string,
  culturalDictionary: CulturalDictionary[],
  interventions: Intervention[]
): AnalysisResult {
  const normalizedMessage = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  
  // Check for crisis first
  const crisisCheck = checkCrisis(normalizedMessage)
  if (crisisCheck.isCrisis) {
    return {
      sentimentScore: -1,
      riskLevel: 'high',
      riskScore: 1.0,
      riskIndicators: ['CRISIS_DETECTED'],
      culturalFlags: [],
      suggestedIntervention: null,
      isCrisis: true,
      crisisTrigger: crisisCheck.trigger
    }
  }

  // Cultural adaptation - translate expressions
  const culturalFlags: string[] = []
  let adaptedMessage = normalizedMessage
  
  for (const entry of culturalDictionary) {
    const expression = entry.expression.toLowerCase()
    if (normalizedMessage.includes(expression)) {
      adaptedMessage = adaptedMessage.replace(expression, entry.normalized_meaning)
      culturalFlags.push(`${entry.expression} -> ${entry.emotional_category}`)
    }
  }

  // Analyze PHQ-9 indicators
  const phq9Matches = analyzeIndicators(adaptedMessage, PHQ9_INDICATORS)
  
  // Analyze GAD-7 indicators
  const gad7Matches = analyzeIndicators(adaptedMessage, GAD7_INDICATORS)
  
  // Calculate risk score
  const riskIndicators = [...phq9Matches, ...gad7Matches]
  const riskScore = calculateRiskScore(phq9Matches.length, gad7Matches.length, culturalFlags.length)
  const riskLevel = getRiskLevel(riskScore)
  
  // Calculate sentiment (simplified)
  const sentimentScore = calculateSentiment(normalizedMessage, riskScore)
  
  // Get appropriate intervention
  const suggestedIntervention = selectIntervention(interventions, riskLevel)

  return {
    sentimentScore,
    riskLevel,
    riskScore,
    riskIndicators,
    culturalFlags,
    suggestedIntervention,
    isCrisis: false,
    crisisTrigger: null
  }
}

function checkCrisis(message: string): { isCrisis: boolean; trigger: string | null } {
  for (const keyword of CRISIS_KEYWORDS) {
    if (message.includes(keyword)) {
      return { isCrisis: true, trigger: keyword }
    }
  }
  return { isCrisis: false, trigger: null }
}

function analyzeIndicators(message: string, indicators: Record<string, string[]>): string[] {
  const matches: string[] = []
  
  for (const [category, keywords] of Object.entries(indicators)) {
    for (const keyword of keywords) {
      if (message.includes(keyword)) {
        matches.push(category)
        break
      }
    }
  }
  
  return matches
}

function calculateRiskScore(phq9Count: number, gad7Count: number, culturalCount: number): number {
  // Weighted scoring
  const phq9Weight = 0.4
  const gad7Weight = 0.35
  const culturalWeight = 0.25
  
  const maxPhq9 = Object.keys(PHQ9_INDICATORS).length
  const maxGad7 = Object.keys(GAD7_INDICATORS).length
  
  const phq9Score = Math.min(phq9Count / maxPhq9, 1) * phq9Weight
  const gad7Score = Math.min(gad7Count / maxGad7, 1) * gad7Weight
  const culturalScore = Math.min(culturalCount / 5, 1) * culturalWeight
  
  return Math.min(phq9Score + gad7Score + culturalScore, 1)
}

function getRiskLevel(score: number): RiskLevel {
  if (score >= 0.6) return 'high'
  if (score >= 0.3) return 'moderate'
  return 'low'
}

function calculateSentiment(message: string, riskScore: number): number {
  // Simplified sentiment: -1 (very negative) to 1 (very positive)
  const positiveWords = ['bien', 'mejor', 'feliz', 'contento', 'alegre', 'tranquilo', 'esperanza', 'gracias']
  const negativeWords = ['mal', 'peor', 'triste', 'ansioso', 'preocupado', 'miedo', 'solo', 'dificil']
  
  let positiveCount = 0
  let negativeCount = 0
  
  for (const word of positiveWords) {
    if (message.includes(word)) positiveCount++
  }
  
  for (const word of negativeWords) {
    if (message.includes(word)) negativeCount++
  }
  
  const wordSentiment = (positiveCount - negativeCount) / Math.max(positiveCount + negativeCount, 1)
  
  // Combine word sentiment with risk score
  return (wordSentiment - riskScore) / 2
}

function selectIntervention(interventions: Intervention[], riskLevel: RiskLevel): Intervention | null {
  const riskOrder: RiskLevel[] = ['low', 'moderate', 'high']
  const currentIndex = riskOrder.indexOf(riskLevel)
  
  const suitable = interventions.filter(i => {
    const minIndex = riskOrder.indexOf(i.min_risk_level)
    const maxIndex = riskOrder.indexOf(i.max_risk_level)
    return currentIndex >= minIndex && currentIndex <= maxIndex && i.is_active
  })
  
  if (suitable.length === 0) return null
  
  // Return random suitable intervention
  return suitable[Math.floor(Math.random() * suitable.length)]
}

export function formatIntervention(intervention: Intervention): string {
  return `
**${intervention.name}**

${intervention.description}

**Instrucciones:**
${intervention.instructions}

*Duracion aproximada: ${intervention.duration_minutes} minutos*
`
}
